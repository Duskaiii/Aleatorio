package com.example.trabpaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.trabpaulinho.modelo.Produto;
import com.example.trabpaulinho.modelo.Cliente;
import com.example.trabpaulinho.modelo.Venda;

import java.util.ArrayList;

public class CadastroVendaActivity extends AppCompatActivity {

    private ArrayList<Cliente> listaCliente;
    private ArrayList<Produto> listaProduto;

    private Spinner spCliente;
    private Spinner spProduto;
    private TextView tvRetornaItens;
    private TextView tvRetornaQtdItens;
    private TextView tvRetornaTotalProd;
    private TextView tvRetornaParcela;
    private TextView tvRetornaTotalFinal;

    private EditText edQuantProd;
    private EditText edValorProd;
    private EditText edQtdParcela;

    private ImageButton btAddProd;
    private ImageButton btCancela;
    private ImageButton btFinaliza;

    private RadioButton rbVista;
    private RadioButton rbPrazo;

    private TextView tvErroProduto;
    private TextView tvErroCliente;

    private int posicaoSelecionadaP = 0;
    private int posicaoSelecionadaC = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancamento_pedido);

        spCliente = findViewById(R.id.spCliente);
        spProduto = findViewById(R.id.spProduto);
        edQuantProd = findViewById(R.id.edQuantProd);
        edValorProd = findViewById(R.id.edValorProd);

        btCancela = findViewById(R.id.btCancela);
        btAddProd = findViewById(R.id.btAddProd);
        tvRetornaItens = findViewById(R.id.tvRetornaItens);
        tvRetornaQtdItens = findViewById(R.id.tvRetornaQtdItens);

        tvRetornaTotalProd = findViewById(R.id.tvRetornaTotalProd);
        rbVista = findViewById(R.id.rbVista);
        rbPrazo = findViewById(R.id.rbPrazo);
        edQtdParcela = findViewById(R.id.edQtdParcela);

        tvRetornaParcela = findViewById(R.id.tvRetornaParcela);
        tvRetornaTotalFinal = findViewById(R.id.tvRetornaTotalFinal);
        btFinaliza = findViewById(R.id.btFinaliza);

        tvErroCliente = findViewById(R.id.tvErroCliente);
        tvErroProduto = findViewById(R.id.tvErroProduto);



        spCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionadaC = posicao;
                    tvErroCliente.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spProduto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView,
                                       View view, int posicao, long l) {
                if(posicao > 0){
                    posicaoSelecionadaP = posicao;
                    tvErroProduto.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btAddProd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adicionarProduto();
            }
        });

        btFinaliza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finalizaVenda();
            }
        });

        carregaClientes();
        carregaProdutos();

        atualizaListaProdutos();

    }

    private void finalizaVenda(){
        if (edQtdParcela.getText().toString().isEmpty()) {
            edQtdParcela.setError("Quantidade de parcelas não informadas!");
            return;
        }

        if(edValorProd.getText().toString().isEmpty()){
            edValorProd.setError("Valor Untário do produto Inválido!");
            return;
        }

        if(edQuantProd.getText().toString().isEmpty()){
            edQuantProd.setError("Quantidade de produtos inválida!");
            return;
        }
        if(posicaoSelecionadaP <= 0){
            tvErroProduto.setVisibility(View.VISIBLE);
            return;
        }

        if(posicaoSelecionadaC <= 0){
            tvErroCliente.setVisibility(View.VISIBLE);
            return;
        }

        Cliente cliente = listaCliente.get(posicaoSelecionadaC-1);

        Produto produto = listaProduto.get(posicaoSelecionadaP-1);

        Venda venda = new Venda();

        venda.setCliente(cliente);

        venda.setProduto(produto);


    }


}