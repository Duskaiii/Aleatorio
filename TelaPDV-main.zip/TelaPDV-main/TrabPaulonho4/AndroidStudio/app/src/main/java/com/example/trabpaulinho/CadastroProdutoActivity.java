package com.example.trabpaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabpaulinho.modelo.Produto;

public class CadastroProdutoActivity extends AppCompatActivity {

    private EditText edCodProduto;
    private EditText edNomeProduto;
    private EditText edVlUnit;
    private Button btGravarP;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_cadastro_produto);


        edCodProduto = findViewById(R.id.edCodProduto);

        edNomeProduto = findViewById(R.id.edNomeProduto);

        edVlUnit = findViewById(R.id.edVlUnit);

        btGravarP = findViewById(R.id.btGravarP);

        btGravarP.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                salvarProduto();
            }
        });
    }

    private void salvarProduto(){


        if(edCodProduto.getText().toString().isEmpty()){
            edCodProduto.setError("Informe o código do cliente!");
            return;
        }

        if(edCodProduto.getText().toString().length() > 10){
            edCodProduto.setError("Excedido o limite máximo de caracteres!");
            return;
        }

        if(edNomeProduto.getText().toString().isEmpty()){
            edNomeProduto.setError("Informe o nome do produto!");
            return;
        }

        if(edVlUnit.getText().toString().isEmpty()){
            edVlUnit.setError("Informe o valor unitario do produto!");
            return;
        }

        Produto produto = new Produto();

        produto.setCodigo(edCodProduto.getText().toString());

        produto.setDescricao(edNomeProduto.getText().toString());

        produto.setValorUn(Double.parseDouble(edVlUnit.getText().toString()));

        Controller.getInstancia().salvarProduto(produto);

        Toast.makeText(CadastroProdutoActivity.this, "Produto cadastrado com sucesso!", Toast.LENGTH_LONG).show();

        this.finish();
    }
}