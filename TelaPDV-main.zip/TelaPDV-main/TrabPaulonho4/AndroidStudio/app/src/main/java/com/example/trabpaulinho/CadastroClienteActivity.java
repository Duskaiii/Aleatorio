package com.example.trabpaulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.trabpaulinho.modelo.Cliente;


public class CadastroClienteActivity extends AppCompatActivity {

    private EditText edNomeCliente;
    private EditText edCpfCliente;

    private Button btGravarC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_cliente);




        edNomeCliente = findViewById(R.id.edNomeCliente);
        edCpfCliente = findViewById(R.id.edCpfCliente);
        btGravarC = findViewById(R.id.btGravarC);


        btGravarC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCliente();
            }
        });
    }

    private void salvarCliente(){
        if(edNomeCliente.getText().toString().isEmpty()){
            edNomeCliente.setError("Informe o nome do cliente!");
            return;
        }
        if (edCpfCliente.getText().toString().isEmpty()){
            edCpfCliente.setError("Informe o CPF do cliente!");
            return;
        }

        Cliente cliente = new Cliente();
        cliente.setNome(edNomeCliente.getText().toString());
        cliente.setCpf(edCpfCliente.getText().toString());

        Controller.getInstancia().salvarCliente(cliente);

        Toast.makeText(CadastroClienteActivity.this, "Cliente Cadastrado com sucesso!", Toast.LENGTH_LONG).show();

        this.finish();

    }
}